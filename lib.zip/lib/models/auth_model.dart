import 'dart:convert';

import 'package:flutter/material.dart';

class AuthModel extends ChangeNotifier {
  bool _isLogin = false;
  Map<String, dynamic> user = {}; //update user details when loggin in
  Map<String, dynamic> appointment =
      {}; //update upcoming appointmnets when loggin in
  List<Map<String, dynamic>> favDoc = []; //get favourite docs
  List<dynamic> _fav = []; //get fav docs id in a list

  bool get isLogin {
    return _isLogin;
  }

  List<dynamic> get getFav {
    return _fav;
  }

  Map<String, dynamic> get getUser {
    return user;
  }

  Map<String, dynamic> get getAppointment {
    return appointment;
  }

//updates latest favourite list and notify all widgets
  void setFavList(List<dynamic> list) {
    _fav = list;
    notifyListeners();
  }

//returns latest favourite doctor list
  List<Map<String, dynamic>> get getFavDoc {
    favDoc.clear(); //clear prvious record before getting the latest list

    //list the doctor list according to favourite list
    for (var num in _fav) {
      for (var doc in user['doctor']) {
        if (num == doc['doc_id']) {
          favDoc.add(doc);
        }
      }
    }
    return favDoc;
  }

//when login is successful, update the status
  void loginSuccess(
      Map<String, dynamic> userData, Map<String, dynamic> appointmentInfo) {
    _isLogin = true;

    //update these data when logging in
    user = userData;
    appointment = appointmentInfo;

    if (user['details']['fav'] != null) {
      _fav = json.decode(
          user['details']['fav']); //details are returned fron user controller
    }

    notifyListeners();
  }
}
