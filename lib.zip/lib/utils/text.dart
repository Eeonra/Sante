//Pre-defined text for app

class AppText {
  static final enText = {
    'welcome_text': 'Welcome To Santé',
    'signIn_text': 'Sign in to your account',
    'registered_text': 'Already have an account?',
    'register_text':
        'You can easily sign up and connect to the Doctor nearby you',
    'signUp_text': 'Don\'t have an account?',
    'social-login': 'Or continue with social account',
    'forgot-password': 'Forgot Your Passowrd',
  };
}
