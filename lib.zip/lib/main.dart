import 'package:doctor_app1/models/auth_model.dart';
import 'package:doctor_app1/main_layout.dart';
import 'package:doctor_app1/screens/auth_pg.dart';
import 'package:doctor_app1/screens/booking_page.dart';
import 'package:doctor_app1/screens/doctor_details.dart';
import 'package:doctor_app1/screens/success_booked.dart';
import 'package:doctor_app1/utils/config.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  //for push navigator
  static final navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    //Defining Theme data here
    return ChangeNotifierProvider<AuthModel>(
      create: (context) => AuthModel(),
      child: MaterialApp(
        navigatorKey: navigatorKey,
        title: 'Santé',
        theme: ThemeData(
            //pre-define input decoration
            inputDecorationTheme: const InputDecorationTheme(
              focusColor: Config.primaryColor,
              border: Config.outlinedBorder,
              focusedBorder: Config.focusBorder,
              errorBorder: Config.errorBorder,
              enabledBorder: Config.outlinedBorder,
              floatingLabelStyle: TextStyle(color: Config.primaryColor),
              prefixIconColor: Colors.black38,
            ),
            scaffoldBackgroundColor: Colors.white,
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              backgroundColor: Config.primaryColor,
              selectedItemColor: Colors.white,
              showSelectedLabels: true,
              showUnselectedLabels: false,
              unselectedItemColor: Colors.grey.shade700,
              elevation: 10,
              type: BottomNavigationBarType.fixed,
            )),
        initialRoute: '/',
        routes: {
          //Initial route of the app i.e. the auth pg
          '/': (context) => const AuthPage(),
          //for main layout after login
          'main': (context) => const MainLayout(),
          'booking_page': (context) => BookingPage(),
          'success_booking': (context) => const AppointmentBooked(),
        },
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
